import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-delte',
  templateUrl: './dialog-delte.component.html',
  styleUrls: ['./dialog-delte.component.css']
})
export class DialogDelteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
