import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qguide',
  templateUrl: './qguide.component.html',
  styleUrls: ['./qguide.component.css']
})
export class QguideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
