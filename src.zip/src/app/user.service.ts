import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from "@angular/router";


@Injectable({
  providedIn: 'root'
})
export class UserService {

  //eventuell ändern:
  private loginUrl = 'http://localhost:3000/login';
  private registerUrl = 'http://localhost:3000/register';

  private loggedin= false;
  

  

  constructor(private httpClient :HttpClient, private router:Router) {}

   public login(uemail,upass) {

    

    this.httpClient.post(this.loginUrl,{email: uemail, pass: upass}).subscribe((res)=>{
      
      
        
         

      console.log(res);

      setTimeout(() => {
        if(res=="found"){
          console.log("YEAH");
          this.loggedin=true;
        this.router.navigate(['/profile']);}
        
      }, 1200);
      
      
    })


    
  }

  public register(uname,uemail,upass) {

    

    this.httpClient.post(this.registerUrl,{user:uname, email: uemail, pass: upass}).subscribe((res)=>{

    
      console.log(res);
      setTimeout(() => {
        if(res=="registered"){
          console.log("YEAH");
        this.router.navigate(['/login']);}
        
      }, 1000);
      
      
    })


    
  }

  isLoggedin(){return this.loggedin;}


 
  



  /* 

    in the making: other functions like logout, delete, update..
  
  }*/

    

}
