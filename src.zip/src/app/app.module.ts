import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AccountComponent } from './account/account.component';

import  {AppRoutingModule} from './app-routing.module';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ReactiveFormsModule } from "@angular/forms";
import { LoginComponent } from './login/login.component';
import { HttpClientModule } from "@angular/common/http";
import { UserService } from "./user.service";
import { ProfileComponent } from './profile/profile.component';
import { AuthGuardService } from './auth-guard.service';
import { QguideComponent } from './qguide/qguide.component';
import { HighscoresComponent } from './highscores/highscores.component';
import { DialogDelteComponent } from './dialog-delte/dialog-delte.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatDialogModule } from '@angular/material';
import { DialogPassComponent } from './dialog-pass/dialog-pass.component';
import { DialogUserComponent } from './dialog-user/dialog-user.component';
import { LogGuardService } from './log-guard.service';

@NgModule({
  declarations: [
    AppComponent,
    AccountComponent,
    HomeComponent,
    AboutComponent,
    LoginComponent,
    ProfileComponent,
    QguideComponent,
    HighscoresComponent,
    DialogDelteComponent,
    DialogPassComponent,
    DialogUserComponent
  ],
  entryComponents:[DialogDelteComponent, DialogPassComponent, DialogUserComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatDialogModule
  ],
  providers: [UserService, AuthGuardService,LogGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
