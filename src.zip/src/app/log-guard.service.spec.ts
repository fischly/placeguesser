import { TestBed } from '@angular/core/testing';

import { LogGuardService } from './log-guard.service';

describe('LogGuardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LogGuardService = TestBed.get(LogGuardService);
    expect(service).toBeTruthy();
  });
});
