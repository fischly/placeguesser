import { Component } from '@angular/core';
import { UserService } from "./user.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'client';

  constructor(private userverice: UserService, private router:Router){}

  protected check = this.userverice.getStatus();

  onclick(){console.log("Quak");this.userverice.logout();}

  login(){this.router.navigate(['/login']);}

  

 



  

}
